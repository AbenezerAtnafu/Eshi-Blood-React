import "./style.css";
import CreateAppointment from "./appointment/create-appointment";
import ProfileDetail from "./profile/profile-detail";


const UserPage = () => {
    return (<>
        {/* <CreateAppointment></CreateAppointment> */}
        <ProfileDetail></ProfileDetail>
        {/* <div class=""><h1>User page</h1></div> */}
    </>
    )
}

export default UserPage;